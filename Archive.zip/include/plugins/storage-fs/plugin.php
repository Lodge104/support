<?php

return array(
    'id' =>             'storage:fs', # notrans
    'version' =>        '0.3',
    'name' =>           /* trans */ 'Attachments on the filesystem',
    'author' =>         'Jared Hancock',
    'description' =>    /* trans */ 'Enables storing attachments on the filesystem',
    'url' =>            'http://www.osticket.com/plugins/storage-fs',
    'plugin' =>         'storage.php:FsStoragePlugin'
);

?>
